"""Hardware-aware verified default model selection for product CLI paths."""

from __future__ import annotations

import os
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

from mtplx.constants import DEFAULT_RUNTIME_MODEL_DIR
from mtplx.hardware import classify_apple_silicon_generation, detect_apple_silicon
from mtplx.profiles import (
    DEFAULT_FP16_PUBLIC_MODEL_ID,
    DEFAULT_FP16_HF_MODEL_ID,
    DEFAULT_HF_MODEL_ID,
    DEFAULT_MODEL_ID,
    DEFAULT_PUBLIC_MODEL_ID,
    LEGACY_OPTIMIZED_PUBLIC_MODEL_ID,
    OPTIMIZED_SPEED_V1_HF_MODEL_ID,
    OPTIMIZED_SPEED_V1_PUBLIC_MODEL_ID,
    OPTIMIZED_SPEED_V2_HF_MODEL_ID,
    OPTIMIZED_SPEED_V2_PUBLIC_MODEL_ID,
    QUALITY_FP16_HF_MODEL_ID,
    QUALITY_FP16_PUBLIC_MODEL_ID,
    QUALITY_HF_MODEL_ID,
    QUALITY_PUBLIC_MODEL_ID,
    QWEN35_9B_OPTIMIZED_SPEED_FP16_HF_MODEL_ID,
    QWEN35_9B_OPTIMIZED_SPEED_FP16_PUBLIC_MODEL_ID,
    QWEN35_9B_OPTIMIZED_SPEED_HF_MODEL_ID,
    QWEN35_9B_OPTIMIZED_SPEED_PUBLIC_MODEL_ID,
    QWEN36_35B_OPTIMIZED_BALANCE_FP16_HF_MODEL_ID,
    QWEN36_35B_OPTIMIZED_BALANCE_FP16_PUBLIC_MODEL_ID,
    QWEN36_35B_OPTIMIZED_BALANCE_HF_MODEL_ID,
    QWEN36_35B_OPTIMIZED_BALANCE_PUBLIC_MODEL_ID,
    QWEN36_35B_OPTIMIZED_SPEED_FP16_HF_MODEL_ID,
    QWEN36_35B_OPTIMIZED_SPEED_FP16_PUBLIC_MODEL_ID,
    QWEN36_35B_OPTIMIZED_SPEED_HF_MODEL_ID,
    QWEN36_35B_OPTIMIZED_SPEED_PUBLIC_MODEL_ID,
    QWEN38_BARE_SPEED_HF_MODEL_ID,
    QWEN38_BARE_SPEED_PUBLIC_MODEL_ID,
    QWEN38_OPTIMIZED_QUALITY_HF_MODEL_ID,
    QWEN38_OPTIMIZED_QUALITY_PUBLIC_MODEL_ID,
    QWEN38_OPTIMIZED_SPEED_HF_MODEL_ID,
    QWEN38_OPTIMIZED_SPEED_PUBLIC_MODEL_ID,
    QWEN38_BARE_SPEED_FP16_HF_MODEL_ID,
    QWEN38_BARE_SPEED_FP16_PUBLIC_MODEL_ID,
    QWEN38_OPTIMIZED_QUALITY_FP16_HF_MODEL_ID,
    QWEN38_OPTIMIZED_QUALITY_FP16_PUBLIC_MODEL_ID,
    QWEN38_OPTIMIZED_SPEED_FP16_HF_MODEL_ID,
    QWEN38_OPTIMIZED_SPEED_FP16_PUBLIC_MODEL_ID,
)


DEFAULT_MODEL_VARIANT_ENV = "MTPLX_DEFAULT_MODEL_VARIANT"
SPEED_MODEL_ENV = "MTPLX_OPTIMIZED_SPEED_MODEL"
QWEN38_BARE_SPEED_MODEL_ENV = "MTPLX_QWEN38_BARE_SPEED_MODEL"
QWEN38_OPTIMIZED_SPEED_MODEL_ENV = "MTPLX_QWEN38_OPTIMIZED_SPEED_MODEL"
QUALITY_MODEL_ENV = "MTPLX_OPTIMIZED_QUALITY_MODEL"
DEFAULT_MODEL_VARIANTS = frozenset({"auto", "speed", "q4", "bf16", "fp16"})
_LEGACY_APPLE_FP16_GENERATIONS = frozenset({"m1", "m2"})
_NEWER_APPLE_SPEED_GENERATIONS = frozenset({"m3", "m4", "m5"})
# Below this much unified memory the 27B default cannot load safely, so the
# default routes to the 9B artifact instead. Mirrors the app's <32 GiB
# recommendation tier (model_catalog.recommended_catalog_ids).
SMALL_DEFAULT_MEMORY_FLOOR_GIB = 32.0
# V2 peaks at about 21.5 GiB, leaving practical headroom on a 32 GiB Mac.
OPTIMIZED_SPEED_V2_MEMORY_FLOOR_GIB = 32.0
# Qwen 3.8 Bare Speed measured peak 17.0 GiB (installed app, 2026-08-14); the
# same 32 GiB floor as V2 is therefore conservative.
QWEN38_BARE_SPEED_MEMORY_FLOOR_GIB = 32.0
# Qwen 3.8 Optimized Speed measured peak 23.6 GiB (installed app, 2026-08-14),
# two GiB above V2's 21.5 on the same instrument; it keeps V2's 32 GiB floor
# (the app additionally hides any pick whose peak exceeds unified memory).
QWEN38_OPTIMIZED_SPEED_MEMORY_FLOOR_GIB = 32.0
QWEN35_9B_SPEED_DESCRIPTION = "Compact 6-bit model for smaller Macs"
OPTIMIZED_SPEED_V1_LABEL = "Qwen 3.6 27B Optimized Speed"
OPTIMIZED_SPEED_V1_DESCRIPTION = "Smaller 4-bit model that is a little faster for short chats"
OPTIMIZED_SPEED_V2_LABEL = "Qwen 3.6 27B Optimized Speed V2"
OPTIMIZED_SPEED_V2_DESCRIPTION = (
    "Much higher quality for coding, with dynamic 4-bit hybrid quantization "
    "and hand-tuned sensitive parts kept at up to 16-bit. Faster on long "
    "agent tasks, slightly larger, and a little slower for short chats"
)
# Qwen 3.8 trio wording (founder, 2026-08-15): plain human descriptions.
QWEN38_BARE_SPEED_LABEL = "Qwen 3.8 27B Bare Speed"
QWEN38_BARE_SPEED_DESCRIPTION = (
    "Quickest burst chat speeds. Lower quality and slower on long coding tasks"
)
QWEN38_OPTIMIZED_SPEED_LABEL = "Qwen 3.8 27B Optimized Speed"
QWEN38_OPTIMIZED_SPEED_DESCRIPTION = (
    "4-bit dynamic quant. Great coding speeds and good quality. Recommended"
)
QWEN38_OPTIMIZED_QUALITY_LABEL = "Qwen 3.8 27B Optimized Quality"
QWEN38_OPTIMIZED_QUALITY_DESCRIPTION = (
    "8-bit dynamic quant. Good coding speeds and perfect quality"
)
QWEN38_BARE_SPEED_FP16_LABEL = "Qwen 3.8 27B Bare Speed FP16"
QWEN38_OPTIMIZED_SPEED_FP16_LABEL = "Qwen 3.8 27B Optimized Speed FP16"
QWEN38_OPTIMIZED_QUALITY_FP16_LABEL = "Qwen 3.8 27B Optimized Quality FP16"
QWEN38_FP16_SUFFIX = "FP16 build for M1 and M2 Macs"
# Backward-compatible names used by integrations that mean the public default.
OPTIMIZED_SPEED_LABEL = QWEN38_OPTIMIZED_SPEED_LABEL
OPTIMIZED_SPEED_DESCRIPTION = QWEN38_OPTIMIZED_SPEED_DESCRIPTION
OPTIMIZED_QUALITY_LABEL = "Qwen3.6 27B MTPLX Optimized Quality"
OPTIMIZED_QUALITY_DESCRIPTION = "Flat8 target with INT8 MTP sidecar"
_QWEN38_BARE_SPEED_LOCAL_CANDIDATES = (
    "~/.mtplx/models/Youssofal--Qwen3.8-27B-MTPLX-Bare-Speed",
    # Forge-local drop-day build (forge writes the branded name directly).
    "~/.mtplx/models/Qwen3.8-27B-MTPLX-Bare-Speed",
)
_QWEN38_OPTIMIZED_SPEED_LOCAL_CANDIDATES = (
    "~/.mtplx/models/Youssofal--Qwen3.8-27B-MTPLX-Optimized-Speed",
    "~/.mtplx/models/Qwen3.8-27B-MTPLX-Optimized-Speed",
)
_QWEN38_OPTIMIZED_QUALITY_LOCAL_CANDIDATES = (
    "~/.mtplx/models/Youssofal--Qwen3.8-27B-MTPLX-Optimized-Quality",
    "~/.mtplx/models/Qwen3.8-27B-MTPLX-Optimized-Quality",
)
_QWEN38_BARE_SPEED_FP16_LOCAL_CANDIDATES = (
    "~/.mtplx/models/Youssofal--Qwen3.8-27B-MTPLX-Bare-Speed-FP16",
    "~/.mtplx/models/Qwen3.8-27B-MTPLX-Bare-Speed-FP16",
)
_QWEN38_OPTIMIZED_SPEED_FP16_LOCAL_CANDIDATES = (
    "~/.mtplx/models/Youssofal--Qwen3.8-27B-MTPLX-Optimized-Speed-FP16",
    "~/.mtplx/models/Qwen3.8-27B-MTPLX-Optimized-Speed-FP16",
)
_QWEN38_OPTIMIZED_QUALITY_FP16_LOCAL_CANDIDATES = (
    "~/.mtplx/models/Youssofal--Qwen3.8-27B-MTPLX-Optimized-Quality-FP16",
    "~/.mtplx/models/Qwen3.8-27B-MTPLX-Optimized-Quality-FP16",
)
_OPTIMIZED_SPEED_V2_LOCAL_CANDIDATES = (
    "~/.mtplx/models/Youssofal--Qwen3.6-27B-MTPLX-Optimized-Speed-V2",
    "~/Documents/MTPLX/models/Qwen3.6-27B-MTPLX-Optimized-Speed-V2",
    "~/Documents/MTPLX/hf-staging/Qwen3.6-27B-MTPLX-Optimized-Speed-V2",
)
_OPTIMIZED_SPEED_V1_LOCAL_CANDIDATES = (
    "~/Documents/MTPLX/models/Qwen3.6-27B-MTPLX-Optimized-Speed",
    "~/.mtplx/hf-upload/Qwen3.6-27B-MTPLX-Optimized-Speed",
    "~/.mtplx/models/Youssofal--Qwen3.6-27B-MTPLX-Optimized-Speed",
    "~/Documents/MTPLX/hf-staging/Qwen3.6-27B-MTPLX-Optimized-Speed",
)
_OPTIMIZED_QUALITY_LOCAL_CANDIDATES = (
    "~/Documents/MTPLX/hf-staging/Qwen3.6-27B-MTPLX-Optimized-Quality",
    "~/.mtplx/models/Youssofal--Qwen3.6-27B-MTPLX-Optimized-Quality",
)
_OPTIMIZED_QUALITY_FP16_LOCAL_CANDIDATES = (
    "~/Documents/MTPLX/hf-staging/Qwen3.6-27B-MTPLX-Optimized-Quality-FP16",
    "~/.mtplx/models/Youssofal--Qwen3.6-27B-MTPLX-Optimized-Quality-FP16",
)
_OPTIMIZED_35B_SPEED_LOCAL_CANDIDATES = (
    "~/Documents/MTPLX/models/Qwen3.6-35B-A3B-MTPLX-Optimized-Speed",
    "~/Documents/MTPLX/models/Qwen3.6-35B-A3B-MTPLX-Official4-CyanKiwiMTP-CleanRecipe",
    "~/.mtplx/models/Youssofal--Qwen3.6-35B-A3B-MTPLX-Optimized-Speed",
)
_VERIFIED_DEFAULT_LOCAL_NAMES = frozenset(
    {
        "Qwen3.8-27B-MTPLX-Optimized-Speed",
        "Youssofal--Qwen3.8-27B-MTPLX-Optimized-Speed",
        "Qwen3.8-27B-MTPLX-Bare-Speed",
        "Youssofal--Qwen3.8-27B-MTPLX-Bare-Speed",
        "Qwen3.8-27B-MTPLX-Optimized-Speed-FP16",
        "Youssofal--Qwen3.8-27B-MTPLX-Optimized-Speed-FP16",
        "Qwen3.6-27B-MTPLX-Optimized-Speed-V2",
        "Youssofal--Qwen3.6-27B-MTPLX-Optimized-Speed-V2",
        "Qwen3.6-27B-MTPLX-Optimized-Speed-FP16",
        "Youssofal--Qwen3.6-27B-MTPLX-Optimized-Speed-FP16",
    }
)


@dataclass(frozen=True)
class DefaultModelSelection:
    model: str
    hf_model: str
    variant: str
    precision: str
    chip_generation: str
    chip: str
    reason: str
    auto_selected: bool
    env_override: str | None = None
    memory_gib: float | None = None

    @property
    def display_name(self) -> str:
        if "9B" in self.hf_model:
            if self.variant == "fp16":
                return "Qwen3.5 9B Optimized Speed FP16"
            return "Qwen3.5 9B Optimized Speed"
        if self.hf_model == QWEN38_OPTIMIZED_SPEED_FP16_HF_MODEL_ID:
            return QWEN38_OPTIMIZED_SPEED_FP16_LABEL
        if self.variant == "fp16":
            return "Qwen3.6 27B Optimized Speed FP16"
        if self.hf_model == OPTIMIZED_SPEED_V1_HF_MODEL_ID:
            return OPTIMIZED_SPEED_V1_LABEL
        if self.hf_model == OPTIMIZED_SPEED_V2_HF_MODEL_ID:
            return OPTIMIZED_SPEED_V2_LABEL
        if self.hf_model == QWEN38_BARE_SPEED_HF_MODEL_ID:
            return QWEN38_BARE_SPEED_LABEL
        return QWEN38_OPTIMIZED_SPEED_LABEL

    @property
    def label(self) -> str:
        return f"{self.display_name}. {self.precision}. {self.reason}."

    def to_dict(self) -> dict[str, Any]:
        return {
            "model": self.model,
            "hf_model": self.hf_model,
            "variant": self.variant,
            "precision": self.precision,
            "chip_generation": self.chip_generation,
            "chip": self.chip,
            "reason": self.reason,
            "auto_selected": self.auto_selected,
            "env_override": self.env_override,
            "memory_gib": self.memory_gib,
            "display_name": self.display_name,
            "label": self.label,
        }


def _repo_root() -> Path:
    return Path(__file__).resolve().parents[1]


def _is_complete_local_model(path: Path) -> bool:
    if not path.is_dir():
        return False
    if (
        (path / "mtplx_pair.json").is_file()
        and (path / "target").is_dir()
        and (path / "assistant").is_dir()
    ):
        return True
    if not (path / "config.json").is_file():
        return False
    has_weights = any(path.glob("model-*.safetensors")) or (path / "model.safetensors").is_file()
    has_mtp = any(
        (path / rel).is_file()
        for rel in ("mtp.safetensors", "mtp/weights.safetensors", "model-mtp.safetensors")
    )
    return has_weights and has_mtp


def _env_ref_disabled(value: str | None) -> bool:
    return str(value or "").strip().lower() in {"0", "false", "no", "none", "off", "disabled"}


def _complete_local_model_ref(candidates: tuple[str, ...]) -> str | None:
    for candidate in candidates:
        if not candidate or _env_ref_disabled(candidate):
            continue
        path = Path(candidate).expanduser()
        if _is_complete_local_model(path):
            return str(path)
    return None


def _optimized_speed_model_ref(
    *,
    hf_model_id: str,
    local_candidates: tuple[str, ...],
    env_name: str = SPEED_MODEL_ENV,
) -> str:
    env_ref = str(os.environ.get(env_name) or "").strip()
    candidates: tuple[str, ...]
    if env_ref:
        if _env_ref_disabled(env_ref):
            return hf_model_id
        else:
            candidates = (env_ref, *local_candidates)
    else:
        candidates = local_candidates
    local = _complete_local_model_ref(candidates)
    return local or hf_model_id


def qwen38_bare_speed_model_ref() -> str:
    """Resolve the complete local release-day Qwen 3.8 Bare Speed build."""

    # The long-standing speed override's explicit value owns default model
    # selection. A V2 path must never be mistaken for this Qwen3.8 artifact,
    # hence the dedicated override below.
    if QWEN38_BARE_SPEED_MODEL_ENV not in os.environ:
        legacy_speed_override = str(os.environ.get(SPEED_MODEL_ENV) or "").strip()
        if legacy_speed_override:
            return QWEN38_BARE_SPEED_HF_MODEL_ID
    return _optimized_speed_model_ref(
        hf_model_id=QWEN38_BARE_SPEED_HF_MODEL_ID,
        local_candidates=_QWEN38_BARE_SPEED_LOCAL_CANDIDATES,
        env_name=QWEN38_BARE_SPEED_MODEL_ENV,
    )


def _legacy_speed_override_active() -> bool:
    """True when MTPLX_OPTIMIZED_SPEED_MODEL names a real 3.6-era artifact.

    Disabled spellings ("off", "0", ...) only switch local resolution off;
    they do not pin the 3.6 lane.
    """

    value = str(os.environ.get(SPEED_MODEL_ENV) or "").strip()
    return bool(value) and not _env_ref_disabled(value)


def _qwen38_speed_env_pins_artifact() -> bool:
    """True when MTPLX_QWEN38_OPTIMIZED_SPEED_MODEL names an artifact.

    A disabled spelling only switches the local 3.8 lookup off (Hub repo);
    it does not silence an explicit legacy 3.6 override.
    """

    value = str(os.environ.get(QWEN38_OPTIMIZED_SPEED_MODEL_ENV) or "").strip()
    return bool(value) and not _env_ref_disabled(value)


def _legacy_speed_override_owns_default() -> bool:
    """An explicit 3.6-era speed override keeps its lane unless a Qwen 3.8
    artifact is pinned explicitly (the more specific pin wins)."""

    return _legacy_speed_override_active() and not _qwen38_speed_env_pins_artifact()


def qwen38_optimized_speed_model_ref() -> str:
    """Resolve the Qwen 3.8 Optimized Speed default (complete local build or Hub)."""

    # Same override discipline as the Bare resolver: an explicit legacy
    # MTPLX_OPTIMIZED_SPEED_MODEL points at a 3.6-era artifact and must never
    # be relabeled as this Qwen3.8 artifact.
    if _legacy_speed_override_owns_default():
        return QWEN38_OPTIMIZED_SPEED_HF_MODEL_ID
    return _optimized_speed_model_ref(
        hf_model_id=QWEN38_OPTIMIZED_SPEED_HF_MODEL_ID,
        local_candidates=_QWEN38_OPTIMIZED_SPEED_LOCAL_CANDIDATES,
        env_name=QWEN38_OPTIMIZED_SPEED_MODEL_ENV,
    )


def qwen38_optimized_quality_model_ref() -> str:
    """Resolve the Qwen 3.8 Optimized Quality pick (complete local build or Hub)."""

    local = _complete_local_model_ref(_QWEN38_OPTIMIZED_QUALITY_LOCAL_CANDIDATES)
    return local or QWEN38_OPTIMIZED_QUALITY_HF_MODEL_ID


def qwen38_optimized_speed_fp16_model_ref() -> str:
    """Resolve the Qwen 3.8 Optimized Speed FP16 sibling (M1/M2 default)."""

    local = _complete_local_model_ref(_QWEN38_OPTIMIZED_SPEED_FP16_LOCAL_CANDIDATES)
    return local or QWEN38_OPTIMIZED_SPEED_FP16_HF_MODEL_ID


def qwen38_bare_speed_fp16_model_ref() -> str:
    """Resolve the Qwen 3.8 Bare Speed FP16 sibling (M1/M2)."""

    local = _complete_local_model_ref(_QWEN38_BARE_SPEED_FP16_LOCAL_CANDIDATES)
    return local or QWEN38_BARE_SPEED_FP16_HF_MODEL_ID


def qwen38_optimized_quality_fp16_model_ref() -> str:
    """Resolve the Qwen 3.8 Optimized Quality FP16 sibling (M1/M2)."""

    local = _complete_local_model_ref(_QWEN38_OPTIMIZED_QUALITY_FP16_LOCAL_CANDIDATES)
    return local or QWEN38_OPTIMIZED_QUALITY_FP16_HF_MODEL_ID


def optimized_speed_model_ref() -> str:
    """Resolve the 3.6 V2 coding artifact without relabeling a V1 folder."""

    return _optimized_speed_model_ref(
        hf_model_id=OPTIMIZED_SPEED_V2_HF_MODEL_ID,
        local_candidates=_OPTIMIZED_SPEED_V2_LOCAL_CANDIDATES,
    )


def optimized_speed_v1_model_ref() -> str:
    """Resolve the original smaller speed model for lower-memory Macs."""

    return _optimized_speed_model_ref(
        hf_model_id=OPTIMIZED_SPEED_V1_HF_MODEL_ID,
        local_candidates=_OPTIMIZED_SPEED_V1_LOCAL_CANDIDATES,
    )


def optimized_quality_model_ref(
    *,
    hardware: Mapping[str, Any] | None = None,
) -> str:
    env_ref = str(os.environ.get(QUALITY_MODEL_ENV) or "").strip()
    env_disabled = _env_ref_disabled(env_ref) if env_ref else False
    if env_ref and not env_disabled:
        local = _complete_local_model_ref((env_ref,))
        if local:
            return local
    # A quality pick on legacy (M1/M2) silicon resolves the FP16 sibling,
    # mirroring the speed lane's precision routing (2.0.1, 2026-07-07).
    hardware_info = dict(detect_apple_silicon() if hardware is None else hardware)
    generation = _hardware_generation(hardware_info)
    if generation in _LEGACY_APPLE_FP16_GENERATIONS:
        if not env_disabled:
            local = _complete_local_model_ref(_OPTIMIZED_QUALITY_FP16_LOCAL_CANDIDATES)
            if local:
                return local
        return QUALITY_FP16_HF_MODEL_ID
    if env_disabled:
        return QUALITY_HF_MODEL_ID
    local = _complete_local_model_ref(_OPTIMIZED_QUALITY_LOCAL_CANDIDATES)
    return local or QUALITY_HF_MODEL_ID


def is_optimized_quality_model_ref(model: str | Path | None) -> bool:
    if model is None:
        return False
    text = str(model).strip()
    if not text:
        return False
    if text == QUALITY_HF_MODEL_ID:
        return True
    return "qwen3.6-27b-mtplx-optimized-quality" in text.lower()


def _read_json(path: Path) -> Mapping[str, Any]:
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return data if isinstance(data, dict) else {}


def _public_model_id_from_metadata(path: Path) -> str | None:
    """Resolve identity from the artifact's explicit runtime contract only.

    Canonical ``mtplx-*`` ids are a first-party claim, so they require a
    true first-party match: an explicit ``public_model_id`` /
    ``served_model_id`` / ``model_id`` written into ``mtplx_runtime.json``,
    or an exact first-party name (handled by ``_public_model_id_from_name``
    on the path). The old fuzzy lanes — ``artifact_role`` substring
    matching, ``verified_on`` model-string inference, ``precision_variant``
    coercion, family-name coercion, and quantization-layout inference —
    all mislabeled third-party builds (nom666/samuelfaj Qwopus artifacts,
    issue #57, PR #77) and were removed in July 2026. Third-party builds
    made with MTPLX tooling carry the same metadata shapes, so nothing
    short of an explicit id is proof of identity.
    """

    runtime = _read_json(path / "mtplx_runtime.json")
    for key in ("public_model_id", "served_model_id", "model_id"):
        value = runtime.get(key)
        if isinstance(value, str) and value.strip():
            return _sanitize_public_model_id(value)
    inferred = _public_model_id_from_name(str(path))
    if inferred:
        return inferred
    # Symlinks are identity-preserving, not inference: a link into the
    # canonical store serves the canonical artifact (issue #268 — turbo and
    # the served id were lost behind /tmp symlinks). Copies under neutral
    # names still need an explicit id claim per the July 2026 fence above.
    try:
        resolved = path.resolve()
    except OSError:
        return None
    if resolved != path:
        return _public_model_id_from_name(str(resolved))
    return None


def _sanitize_public_model_id(value: str) -> str:
    lowered = str(value).strip().lower()
    lowered = lowered.replace("_", "-")
    lowered = re.sub(r"[^a-z0-9.-]+", "-", lowered)
    lowered = re.sub(r"-{2,}", "-", lowered).strip("-.")
    return lowered or DEFAULT_PUBLIC_MODEL_ID


def _ref_name_components(text: str) -> set[str]:
    """Complete artifact-name components of a model ref, lowered.

    A ref names its artifact as a whole path component (local dirs), an
    HF repo id ("org/name" — also derived from adjacent components and
    from HF cache dirs "models--org--name"), or the bare ref string.
    First-party names are matched against these with EQUALITY: substring
    matching against the whole ref claimed derivative artifacts whose
    folder name merely CONTAINS a first-party name (…-V3-RC, …-V2) as
    the first-party id — the served id, health payload, and app model
    chip then all lied about which model was loaded (reported live
    2026-07-31; same class as issue #57 / PR #77).
    """

    lowered = text.strip().replace("\\", "/").lower()
    parts = [part for part in lowered.split("/") if part]
    components = set(parts)
    components.add(lowered)
    for left, right in zip(parts, parts[1:]):
        components.add(f"{left}/{right}")
    for part in parts:
        if "--" not in part:
            continue
        # "--" joins org/name segments in both HF cache dirs
        # (models--org--name) and first-party local dir names
        # (Youssofal--Name): expose the terminal name and the org/name
        # pair as components of their own.
        segments = [seg for seg in part.split("--") if seg]
        if not segments:
            continue
        components.add(segments[-1])
        if len(segments) >= 2:
            components.add(f"{segments[-2]}/{segments[-1]}")
    return components


def _public_model_id_from_name(value: str) -> str | None:
    """Map exact first-party names (public ids, HF repo ids, released
    folder names) to their canonical public ids.

    Every pattern here is a complete first-party artifact name, compared
    for EQUALITY against the ref's name components (never substrings of
    the whole ref). Loose family matches were removed in July 2026
    (issue #57 / PR #77 class), and substring matches were removed
    2026-07-31 after a derivative folder (…-Optimized-Speed-V3-RC) was
    served under the flagship id: any name that merely resembles or
    extends a first-party artifact falls through to the sanitized
    artifact name.
    """

    text = value.strip()
    if not text:
        return None
    lowered = text.replace("\\", "/").lower()
    components = _ref_name_components(text)
    if QWEN35_9B_OPTIMIZED_SPEED_FP16_PUBLIC_MODEL_ID in components:
        return QWEN35_9B_OPTIMIZED_SPEED_FP16_PUBLIC_MODEL_ID
    if QWEN35_9B_OPTIMIZED_SPEED_PUBLIC_MODEL_ID in components:
        return QWEN35_9B_OPTIMIZED_SPEED_PUBLIC_MODEL_ID
    if QWEN35_9B_OPTIMIZED_SPEED_FP16_HF_MODEL_ID.lower() in components:
        return QWEN35_9B_OPTIMIZED_SPEED_FP16_PUBLIC_MODEL_ID
    if QWEN35_9B_OPTIMIZED_SPEED_HF_MODEL_ID.lower() in components:
        return QWEN35_9B_OPTIMIZED_SPEED_PUBLIC_MODEL_ID
    if "qwen3.5-9b-mtplx-optimized-speed-fp16" in components:
        return QWEN35_9B_OPTIMIZED_SPEED_FP16_PUBLIC_MODEL_ID
    if "qwen3.5-9b-mtplx-optimized-speed" in components:
        return QWEN35_9B_OPTIMIZED_SPEED_PUBLIC_MODEL_ID
    if any("qwen3.5-9b-mtplx-speed-6bit" in part for part in components):
        # Deliberate wildcard family (released artifacts are named
        # Qwen-Qwen3.5-9B-MTPLX-Speed-6bit-<suffix>): containment is
        # per-component, so it can no longer match across path pieces.
        return QWEN35_9B_OPTIMIZED_SPEED_PUBLIC_MODEL_ID
    if QWEN36_35B_OPTIMIZED_BALANCE_FP16_PUBLIC_MODEL_ID in components:
        return QWEN36_35B_OPTIMIZED_BALANCE_FP16_PUBLIC_MODEL_ID
    if QWEN36_35B_OPTIMIZED_BALANCE_PUBLIC_MODEL_ID in components:
        return QWEN36_35B_OPTIMIZED_BALANCE_PUBLIC_MODEL_ID
    if QWEN36_35B_OPTIMIZED_BALANCE_FP16_HF_MODEL_ID.lower() in components:
        return QWEN36_35B_OPTIMIZED_BALANCE_FP16_PUBLIC_MODEL_ID
    if QWEN36_35B_OPTIMIZED_BALANCE_HF_MODEL_ID.lower() in components:
        return QWEN36_35B_OPTIMIZED_BALANCE_PUBLIC_MODEL_ID
    if "qwen3.6-35b-a3b-mtplx-optimized-balance-fp16" in components:
        return QWEN36_35B_OPTIMIZED_BALANCE_FP16_PUBLIC_MODEL_ID
    if "qwen3.6-35b-a3b-mtplx-optimized-balance" in components:
        return QWEN36_35B_OPTIMIZED_BALANCE_PUBLIC_MODEL_ID
    if QWEN36_35B_OPTIMIZED_SPEED_FP16_PUBLIC_MODEL_ID in components:
        return QWEN36_35B_OPTIMIZED_SPEED_FP16_PUBLIC_MODEL_ID
    if QWEN36_35B_OPTIMIZED_SPEED_PUBLIC_MODEL_ID in components:
        return QWEN36_35B_OPTIMIZED_SPEED_PUBLIC_MODEL_ID
    if QWEN36_35B_OPTIMIZED_SPEED_FP16_HF_MODEL_ID.lower() in components:
        return QWEN36_35B_OPTIMIZED_SPEED_FP16_PUBLIC_MODEL_ID
    if QWEN36_35B_OPTIMIZED_SPEED_HF_MODEL_ID.lower() in components:
        return QWEN36_35B_OPTIMIZED_SPEED_PUBLIC_MODEL_ID
    if "qwen3.6-35b-a3b-mtplx-optimized-speed-fp16" in components:
        return QWEN36_35B_OPTIMIZED_SPEED_FP16_PUBLIC_MODEL_ID
    if "qwen3.6-35b-a3b-mtplx-optimized-speed" in components:
        return QWEN36_35B_OPTIMIZED_SPEED_PUBLIC_MODEL_ID
    if "qwen3.6-35b-a3b-mtplx-official4-cyankiwimtp-cleanrecipe" in components:
        # First-party local research build of the released 35B speed
        # artifact (listed in _OPTIMIZED_35B_SPEED_LOCAL_CANDIDATES).
        return QWEN36_35B_OPTIMIZED_SPEED_PUBLIC_MODEL_ID
    if QWEN38_BARE_SPEED_FP16_PUBLIC_MODEL_ID in components:
        return QWEN38_BARE_SPEED_FP16_PUBLIC_MODEL_ID
    if QWEN38_BARE_SPEED_FP16_HF_MODEL_ID.lower() in components:
        return QWEN38_BARE_SPEED_FP16_PUBLIC_MODEL_ID
    if "qwen3.8-27b-mtplx-bare-speed-fp16" in components:
        return QWEN38_BARE_SPEED_FP16_PUBLIC_MODEL_ID
    if QWEN38_OPTIMIZED_QUALITY_FP16_PUBLIC_MODEL_ID in components:
        return QWEN38_OPTIMIZED_QUALITY_FP16_PUBLIC_MODEL_ID
    if QWEN38_OPTIMIZED_QUALITY_FP16_HF_MODEL_ID.lower() in components:
        return QWEN38_OPTIMIZED_QUALITY_FP16_PUBLIC_MODEL_ID
    if "qwen3.8-27b-mtplx-optimized-quality-fp16" in components:
        return QWEN38_OPTIMIZED_QUALITY_FP16_PUBLIC_MODEL_ID
    if QWEN38_OPTIMIZED_SPEED_FP16_PUBLIC_MODEL_ID in components:
        return QWEN38_OPTIMIZED_SPEED_FP16_PUBLIC_MODEL_ID
    if QWEN38_OPTIMIZED_SPEED_FP16_HF_MODEL_ID.lower() in components:
        return QWEN38_OPTIMIZED_SPEED_FP16_PUBLIC_MODEL_ID
    if "qwen3.8-27b-mtplx-optimized-speed-fp16" in components:
        return QWEN38_OPTIMIZED_SPEED_FP16_PUBLIC_MODEL_ID
    if QWEN38_BARE_SPEED_PUBLIC_MODEL_ID in components:
        return QWEN38_BARE_SPEED_PUBLIC_MODEL_ID
    if QWEN38_BARE_SPEED_HF_MODEL_ID.lower() in components:
        return QWEN38_BARE_SPEED_PUBLIC_MODEL_ID
    if "qwen3.8-27b-mtplx-bare-speed" in components:
        return QWEN38_BARE_SPEED_PUBLIC_MODEL_ID
    if QWEN38_OPTIMIZED_QUALITY_PUBLIC_MODEL_ID in components:
        return QWEN38_OPTIMIZED_QUALITY_PUBLIC_MODEL_ID
    if QWEN38_OPTIMIZED_QUALITY_HF_MODEL_ID.lower() in components:
        return QWEN38_OPTIMIZED_QUALITY_PUBLIC_MODEL_ID
    if "qwen3.8-27b-mtplx-optimized-quality" in components:
        return QWEN38_OPTIMIZED_QUALITY_PUBLIC_MODEL_ID
    if QWEN38_OPTIMIZED_SPEED_PUBLIC_MODEL_ID in components:
        return QWEN38_OPTIMIZED_SPEED_PUBLIC_MODEL_ID
    if QWEN38_OPTIMIZED_SPEED_HF_MODEL_ID.lower() in components:
        return QWEN38_OPTIMIZED_SPEED_PUBLIC_MODEL_ID
    if "qwen3.8-27b-mtplx-optimized-speed" in components:
        return QWEN38_OPTIMIZED_SPEED_PUBLIC_MODEL_ID
    if "qwen3.6-27b-mtplx-optimized-quality-fp16" in components:
        return QUALITY_FP16_PUBLIC_MODEL_ID
    if "qwen3.6-27b-mtplx-optimized-quality" in components:
        return QUALITY_PUBLIC_MODEL_ID
    if OPTIMIZED_SPEED_V2_PUBLIC_MODEL_ID in components:
        return OPTIMIZED_SPEED_V2_PUBLIC_MODEL_ID
    if OPTIMIZED_SPEED_V2_HF_MODEL_ID.lower() in components:
        return OPTIMIZED_SPEED_V2_PUBLIC_MODEL_ID
    if "qwen3.6-27b-mtplx-optimized-speed-v2" in components:
        return OPTIMIZED_SPEED_V2_PUBLIC_MODEL_ID
    if "qwen3.6-27b-mtplx-optimized-speed-fp16" in components:
        return DEFAULT_FP16_PUBLIC_MODEL_ID
    if OPTIMIZED_SPEED_V1_PUBLIC_MODEL_ID in components:
        return OPTIMIZED_SPEED_V1_PUBLIC_MODEL_ID
    if OPTIMIZED_SPEED_V1_HF_MODEL_ID.lower() in components:
        return OPTIMIZED_SPEED_V1_PUBLIC_MODEL_ID
    if "qwen3.6-27b-mtplx-optimized-speed" in components:
        return OPTIMIZED_SPEED_V1_PUBLIC_MODEL_ID
    legacy_names = {
        "qwen3.6-27b-mtplx-optimized",
        "youssofal--qwen3.6-27b-mtplx-optimized",
    }
    basename = Path(text).name.lower()
    if basename in legacy_names or lowered.endswith("/qwen3.6-27b-mtplx-optimized"):
        return LEGACY_OPTIMIZED_PUBLIC_MODEL_ID
    return None


def public_model_id_for_ref(
    model: str | Path | None,
    *,
    default_model_id: str = DEFAULT_PUBLIC_MODEL_ID,
) -> str:
    """Return the served OpenAI model id for the selected artifact.

    The default public id is only used when no model was provided. Once a
    concrete repo/path exists, MTPLX should report that artifact instead of
    silently claiming the speed default.
    """

    if model is None:
        return default_model_id
    text = str(model).strip()
    if not text:
        return default_model_id
    path = Path(text).expanduser()
    if path.is_dir():
        inferred = _public_model_id_from_metadata(path)
        if inferred:
            return inferred
    inferred = _public_model_id_from_name(text)
    if inferred:
        return inferred
    basename = Path(text).name or text.split("/")[-1]
    return _sanitize_public_model_id(basename)


def _normalize_variant(value: str | None) -> tuple[str, str | None]:
    raw = str(value or "").strip().lower()
    if raw in {"", "auto"}:
        return "auto", None
    aliases = {
        "speed": "speed",
        "optimized-speed": "speed",
        "q4": "speed",
        "int4": "speed",
        "bf16": "speed",
        "bfloat16": "speed",
        "bfloat": "speed",
        "fp16": "fp16",
        "float16": "fp16",
        "f16": "fp16",
    }
    normalized = aliases.get(raw)
    if normalized is None:
        return "auto", raw
    return normalized, raw


def _hardware_generation(hardware: Mapping[str, Any]) -> str:
    generation = str(hardware.get("apple_silicon_generation") or "").strip().lower()
    if generation:
        return generation
    return classify_apple_silicon_generation(
        str(hardware.get("chip") or ""),
        system=str(hardware.get("system") or ""),
        machine=str(hardware.get("machine") or ""),
    )


def _hardware_memory_gib(hardware: Mapping[str, Any]) -> float | None:
    value = hardware.get("memory_gib")
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    return float(value) if value > 0 else None


def select_default_model(
    *,
    variant_override: str | None = None,
    hardware: Mapping[str, Any] | None = None,
) -> DefaultModelSelection:
    """Select the verified default model for this machine.

    Auto policy is intentionally simple and visible: M1/M2 -> FP16, under
    32 GiB -> 9B, and modern Macs with at least 32 GiB -> Qwen 3.8 Optimized
    Speed (the complete local build when installed, otherwise the published
    Hub repo). An explicit legacy MTPLX_OPTIMIZED_SPEED_MODEL override keeps
    the 3.6 Optimized Speed V2 lane it was written for.
    """

    env_value = variant_override if variant_override is not None else os.environ.get(DEFAULT_MODEL_VARIANT_ENV)
    requested_variant, invalid_override = _normalize_variant(env_value)
    hardware_info = dict(detect_apple_silicon() if hardware is None else hardware)
    generation = _hardware_generation(hardware_info)
    chip = str(hardware_info.get("chip") or "").strip()
    memory_gib = _hardware_memory_gib(hardware_info)

    if requested_variant == "fp16":
        variant = "fp16"
        reason = f"forced by {DEFAULT_MODEL_VARIANT_ENV}=fp16"
        auto_selected = False
    elif requested_variant == "speed":
        variant = "speed"
        if str(env_value or "").strip().lower() in {"bf16", "bfloat16", "bfloat"}:
            reason = f"forced by {DEFAULT_MODEL_VARIANT_ENV}={env_value} (legacy alias for optimized speed)"
        else:
            reason = f"forced by {DEFAULT_MODEL_VARIANT_ENV}=speed"
        auto_selected = False
    elif generation in _LEGACY_APPLE_FP16_GENERATIONS:
        variant = "fp16"
        reason = "selected for M1/M2 Apple Silicon"
        auto_selected = True
    else:
        variant = "speed"
        auto_selected = True
        if generation in _NEWER_APPLE_SPEED_GENERATIONS:
            reason = "selected for newer Apple Silicon"
        elif generation == "intel":
            reason = "selected because this is not Apple Silicon"
        else:
            reason = "selected because hardware is unknown"

    if invalid_override is not None and requested_variant == "auto":
        reason = f"{reason}; ignored invalid {DEFAULT_MODEL_VARIANT_ENV}={invalid_override}"

    route_small = (
        memory_gib is not None and memory_gib < SMALL_DEFAULT_MEMORY_FLOOR_GIB
    )
    qwen38_model = qwen38_optimized_speed_model_ref()
    legacy_speed_override = _legacy_speed_override_owns_default()
    use_qwen38 = (
        variant == "speed"
        and generation not in _LEGACY_APPLE_FP16_GENERATIONS
        and not legacy_speed_override
        and (
            memory_gib is None
            or memory_gib >= QWEN38_OPTIMIZED_SPEED_MEMORY_FLOOR_GIB
        )
    )
    use_v2 = (
        variant == "speed"
        and generation not in _LEGACY_APPLE_FP16_GENERATIONS
        and (
            memory_gib is None
            or memory_gib >= OPTIMIZED_SPEED_V2_MEMORY_FLOOR_GIB
        )
    )
    if route_small:
        # The variant override still controls precision; memory routing only
        # changes the model size, mirroring the app's <32 GiB tier.
        reason = (
            f"{reason}; routed to 9B for {memory_gib:.0f} GiB unified memory"
        )
        if variant == "fp16":
            model = QWEN35_9B_OPTIMIZED_SPEED_FP16_HF_MODEL_ID
            hf_model = QWEN35_9B_OPTIMIZED_SPEED_FP16_HF_MODEL_ID
            precision = "FP16"
        else:
            model = QWEN35_9B_OPTIMIZED_SPEED_HF_MODEL_ID
            hf_model = QWEN35_9B_OPTIMIZED_SPEED_HF_MODEL_ID
            precision = QWEN35_9B_SPEED_DESCRIPTION
    elif variant == "fp16":
        if legacy_speed_override:
            # An explicit 3.6-era speed override keeps its FP16 sibling.
            model = DEFAULT_FP16_HF_MODEL_ID
            hf_model = DEFAULT_FP16_HF_MODEL_ID
            precision = "FP16"
        else:
            model = qwen38_optimized_speed_fp16_model_ref()
            hf_model = QWEN38_OPTIMIZED_SPEED_FP16_HF_MODEL_ID
            precision = f"{QWEN38_FP16_SUFFIX}. {QWEN38_OPTIMIZED_SPEED_DESCRIPTION}"
            if model != hf_model:
                reason = f"{reason}; installed locally"
    elif use_qwen38:
        model = qwen38_model
        hf_model = QWEN38_OPTIMIZED_SPEED_HF_MODEL_ID
        precision = QWEN38_OPTIMIZED_SPEED_DESCRIPTION
        if model != hf_model:
            reason = f"{reason}; installed locally"
    elif use_v2:
        model = optimized_speed_model_ref()
        hf_model = OPTIMIZED_SPEED_V2_HF_MODEL_ID
        precision = OPTIMIZED_SPEED_V2_DESCRIPTION
        if model != hf_model:
            reason = f"{reason}; installed locally"
    else:
        model = optimized_speed_v1_model_ref()
        hf_model = OPTIMIZED_SPEED_V1_HF_MODEL_ID
        precision = OPTIMIZED_SPEED_V1_DESCRIPTION
        if memory_gib is not None:
            reason = (
                f"{reason}; selected the smaller model for "
                f"{memory_gib:.0f} GiB unified memory"
            )
        if model != hf_model:
            reason = f"{reason}; installed locally"
    return DefaultModelSelection(
        model=model,
        hf_model=hf_model,
        variant=variant,
        precision=precision,
        chip_generation=generation,
        chip=chip,
        reason=reason,
        memory_gib=memory_gib,
        auto_selected=auto_selected,
        env_override=env_value if env_value else None,
    )


def verified_default_refs() -> set[str]:
    root = _repo_root()
    local_qwen38_os = qwen38_optimized_speed_model_ref()
    local_qwen38_bare = qwen38_bare_speed_model_ref()
    local_speed = optimized_speed_model_ref()
    refs = {
        DEFAULT_HF_MODEL_ID,
        DEFAULT_FP16_HF_MODEL_ID,
        DEFAULT_MODEL_ID,
        OPTIMIZED_SPEED_V2_HF_MODEL_ID,
        local_speed,
        str(DEFAULT_RUNTIME_MODEL_DIR),
        str((root / DEFAULT_RUNTIME_MODEL_DIR).resolve()),
    }
    if local_qwen38_os != QWEN38_OPTIMIZED_SPEED_HF_MODEL_ID:
        refs.add(local_qwen38_os)
    if local_qwen38_bare != QWEN38_BARE_SPEED_HF_MODEL_ID:
        refs.add(local_qwen38_bare)
    refs.add(QWEN38_OPTIMIZED_SPEED_FP16_HF_MODEL_ID)
    local_qwen38_os_fp16 = qwen38_optimized_speed_fp16_model_ref()
    if local_qwen38_os_fp16 != QWEN38_OPTIMIZED_SPEED_FP16_HF_MODEL_ID:
        refs.add(local_qwen38_os_fp16)
    return {ref for ref in refs if ref}


def is_verified_default_model_ref(model: str | Path | None) -> bool:
    if model is None:
        return True
    text = str(model).strip()
    if not text:
        return True
    refs = verified_default_refs()
    if text in refs:
        return True
    if text.startswith(("~", "/", "./", "../")):
        path = Path(text).expanduser()
        if path.name in _VERIFIED_DEFAULT_LOCAL_NAMES:
            return True
        try:
            expanded = str(path.resolve())
        except OSError:
            expanded = str(path)
        return expanded in refs
    return False
